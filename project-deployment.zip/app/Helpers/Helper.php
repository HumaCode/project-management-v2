<?php

use App\Models\Konfigurasi\Menu;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

if (!function_exists('tgl_indo')) {
    function tgl_indo($tgl, $tampil_hari = false, $tampil_jam = false)
    {
        if (!$tgl) return null;

        // 🔹 Kalau input adalah Carbon instance, ubah ke string Y-m-d H:i:s
        if ($tgl instanceof \Carbon\Carbon) {
            $tgl = $tgl->format('Y-m-d H:i:s');
        }

        $nama_hari  = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum\'at', 'Sabtu'];
        $nama_bulan = [
            1 => 'Januari',
            'Februari',
            'Maret',
            'April',
            'Mei',
            'Juni',
            'Juli',
            'Agustus',
            'September',
            'Oktober',
            'November',
            'Desember'
        ];

        $tahun   = substr($tgl, 0, 4);
        $bulan   = $nama_bulan[(int) substr($tgl, 5, 2)];
        $tanggal = substr($tgl, 8, 2);
        $text    = '';

        if ($tampil_hari) {
            $urutan_hari = date('w', strtotime($tgl));
            $hari        = $nama_hari[$urutan_hari];
            $text        = "$hari, $tanggal $bulan $tahun";
        } else {
            $text = "$tanggal $bulan $tahun";
        }

        if ($tampil_jam) {
            $jam = substr($tgl, 11, 5);
            $text .= " - $jam";
        }

        return $text;
    }
}

if (!function_exists('user')) {
    /**
     * Helper sakti untuk data user login, nama, inisial, dan Spatie Role/Permission.
     */
    function user($field = null, $limit = null)
    {
        $user = Auth::user();

        if (!$user) {
            return null;
        }

        // 1. Jika panggil user() tanpa parameter, return object user utuh
        if (is_null($field)) {
            return $user;
        }

        // 2. Gunakan Accessor dari Model User (Lebih konsisten & hemat memori)
        if ($field === 'initial') {
            return $user->initials;
        }

        if ($field === 'avatar') {
            return $user->display_avatar;
        }

        // 3. Logika khusus untuk 'name' dengan limit kata
        if ($field === 'name' && is_numeric($limit)) {
            $words = explode(' ', $user->name);
            return implode(' ', array_slice($words, 0, $limit));
        }

        // 4. Integrasi Spatie: Cek Role (user('is', 'admin'))
        if ($field === 'is') {
            return $user->hasRole($limit); // $limit di sini berfungsi sebagai nama role
        }

        // 5. Integrasi Spatie: Cek Permission (user('can', 'edit-post'))
        if ($field === 'can') {
            return $user->can($limit); // $limit di sini berfungsi sebagai nama permission
        }

        // 6. Integrasi Spatie: Ambil Nama Role Pertama (user('role'))
        if ($field === 'role') {
            return $user->getRoleNames()->first();
        }

        // 7. Default: ambil field dari database (id, email, username, dll)
        return $user->$field ?? null;
    }
}


if (!function_exists('menus')) {
    function menus($grouped = true)
    {
        // 1. Ambil data asli (flat) dari cache agar query hanya 1x
        $allMenus = Cache::rememberForever('menus_data', function () {
            return Menu::active()
                ->orderBy('orders')
                ->get();
        });

        // 2. Jika minta grouped (untuk Sidebar), lakukan grouping di memori PHP
        if ($grouped) {
            return $allMenus->groupBy('category');
        }

        // 3. Jika tidak, kembalikan data flat (untuk urlMenu)
        return $allMenus;
    }
}

if (!function_exists('urlMenu')) {
    function urlMenu()
    {
        // Cache hasil akhir array URL agar tidak perlu pluck() di setiap request
        return Cache::rememberForever('menus_url_list', function () {
            return menus(false)->whereNotNull('url')->pluck('url')->toArray();
        });
    }
}
