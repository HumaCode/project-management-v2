<?php

namespace App\Http\Resources\Dokumen;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DokumenResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'nama' => $this->nama,
            'versi' => $this->versi,
            'kategori' => $this->kategori,
            'kategori_label' => $this->kategori_label,
            'tanggal_upload' => $this->tanggal_upload->format('d M Y'),
            'tanggal_upload_raw' => $this->tanggal_upload->format('Y-m-d'),
            'keterangan' => $this->keterangan,
            'type' => $this->type,
            'status' => $this->status,
            'project' => [
                'id' => $this->project->id ?? null,
                'name' => $this->project->name ?? 'N/A',
            ],
            'uploader' => [
                'id' => $this->uploader->id ?? null,
                'name' => $this->uploader->name ?? 'System',
                'avatar_url' => $this->uploader->avatar_url ?? null,
            ],
            'file_info' => [
                'extension' => $this->getFirstMedia('files')->extension ?? ($this->type === 'article' ? 'ARTICLE' : ($this->type === 'code' ? 'CODE' : 'FILE')),
                'size' => $this->file_size_label,
                'url' => $this->getFirstMediaUrl('files'),
            ],
            'created_at' => $this->created_at->format('d M Y H:i'),
        ];
    }
}
