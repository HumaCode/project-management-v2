<?php

namespace App\Providers;

use App\Interface\Catatan\CatatanRepositoryInterface;
use App\Interface\Catatan\CatatanServiceInterface;
use App\Repositories\Catatan\CatatanRepository;
use App\Services\Catatan\CatatanService;
use App\Interface\RoleManagement\PermissionRepositoryInterface;
use App\Interface\RoleManagement\PermissionServiceInterface;
use App\Interface\RoleManagement\RoleRepositoryInterface;
use App\Interface\RoleManagement\RoleServiceInterface;
use App\Interface\RoleManagement\UserRepositoryInterface;
use App\Interface\RoleManagement\UserServiceInterface;
use App\Interface\Project\ProjectServiceInterface;
use App\Interface\Setting\ProfileRepositoryInterface;
use App\Repositories\RoleManagement\PermissionRepository;
use App\Repositories\RoleManagement\RoleRepository;
use App\Repositories\RoleManagement\UserRepository;
use App\Repositories\Setting\ProfileRepository;
use App\Services\Project\ProjectService;
use App\Services\RoleManagement\PermissionService;
use App\Services\RoleManagement\RoleService;
use App\Services\RoleManagement\UserService;
use App\Interface\Team\TeamServiceInterface;
use App\Services\Team\TeamService;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // role
        $this->app->bind(RoleRepositoryInterface::class, RoleRepository::class);
        $this->app->bind(RoleServiceInterface::class, RoleService::class);

        // permission
        $this->app->bind(PermissionRepositoryInterface::class, PermissionRepository::class);
        $this->app->bind(PermissionServiceInterface::class, PermissionService::class);

        // users
        $this->app->bind(UserRepositoryInterface::class, UserRepository::class);
        $this->app->bind(UserServiceInterface::class, UserService::class);

        // profile
        $this->app->bind(ProfileRepositoryInterface::class, ProfileRepository::class);

        // project
        $this->app->bind(ProjectServiceInterface::class, ProjectService::class);

        // dokumen
        $this->app->bind(\App\Interface\Dokumen\DokumenRepositoryInterface::class, \App\Repositories\Dokumen\DokumenRepository::class);
        $this->app->bind(\App\Interface\Dokumen\DokumenServiceInterface::class, \App\Services\Dokumen\DokumenService::class);

        // catatan
        $this->app->bind(CatatanRepositoryInterface::class, CatatanRepository::class);
        $this->app->bind(CatatanServiceInterface::class, CatatanService::class);

        // team
        $this->app->bind(\App\Interface\Team\TeamRepositoryInterface::class, \App\Repositories\Team\TeamRepository::class);
        $this->app->bind(TeamServiceInterface::class, TeamService::class);

        // kategori dokumen
        $this->app->bind(\App\Interface\KategoriDokumen\KategoriDokumenRepositoryInterface::class, \App\Repositories\KategoriDokumen\KategoriDokumenRepository::class);
        $this->app->bind(\App\Interface\KategoriDokumen\KategoriDokumenServiceInterface::class, \App\Services\KategoriDokumen\KategoriDokumenService::class);

        // dashboard
        $this->app->bind(\App\Repositories\Dashboard\DashboardRepositoryInterface::class, \App\Repositories\Dashboard\DashboardRepository::class);
        $this->app->bind(\App\Interfaces\Dashboard\DashboardServiceInterface::class, \App\Services\Dashboard\DashboardService::class);

        // report
        $this->app->bind(\App\Interface\Report\ReportServiceInterface::class, \App\Services\Report\ReportService::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        view()->composer(['layouts.master', 'layouts.guest'], \App\Http\ViewComposers\SettingComposer::class);

        // Global Mail Config Override from Database
        try {
            if (\Schema::hasTable('settings')) {
                $mailSettings = \App\Models\Setting::where('group', 'email')->pluck('value', 'key');
                
                if ($mailSettings->isNotEmpty()) {
                    config([
                        'mail.mailers.smtp.host'       => $mailSettings['mail_host'] ?? config('mail.mailers.smtp.host'),
                        'mail.mailers.smtp.port'       => $mailSettings['mail_port'] ?? config('mail.mailers.smtp.port'),
                        'mail.mailers.smtp.username'   => $mailSettings['mail_username'] ?? config('mail.mailers.smtp.username'),
                        'mail.mailers.smtp.password'   => $mailSettings['mail_password'] ?? config('mail.mailers.smtp.password'),
                        'mail.mailers.smtp.encryption' => $mailSettings['mail_encryption'] ?? config('mail.mailers.smtp.encryption'),
                        'mail.from.address'            => $mailSettings['mail_from_address'] ?? config('mail.from.address'),
                        'mail.from.name'               => $mailSettings['mail_from_name'] ?? config('mail.from.name'),
                    ]);
                }
            }
        } catch (\Exception $e) {
            // Silently fail if DB not connected or table not found during migration
        }

        // Memodifikasi tampilan email Reset Password
        ResetPassword::toMailUsing(function (object $notifiable, string $token) {

            // 1. Generate URL link reset bawaan Laravel
            $url = url(route('password.reset', [
                'token' => $token,
                'email' => $notifiable->getEmailForPasswordReset(),
            ], false));

            // 2. Arahkan ke custom view yang sudah kita buat tadi
            return (new MailMessage)
                ->subject('Permintaan Reset Password') // Ubah subjek email sesuai selera
                ->view('emails.custom-reset-password', [
                    'url' => $url,
                    'notifiable' => $notifiable,
                ]);
        });

        // Register Backup Listener
        \Illuminate\Support\Facades\Event::listen(
            \Spatie\Backup\Events\BackupWasSuccessful::class,
            \App\Listeners\BackupSuccessfulListener::class
        );
    }
}
