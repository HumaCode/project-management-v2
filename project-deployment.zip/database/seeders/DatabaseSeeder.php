<?php

namespace Database\Seeders;

use Database\Seeders\Konfigurasi\MenuSeeder;
use Database\Seeders\Shield\RoleSeeder;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    // use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {

        $this->call([
            RoleSeeder::class,
            UserSeeder::class,
            MenuSeeder::class,
            ProjectSeeder::class,
            DokumenSeeder::class,
            KategoriDokumenSeeder::class,
            SettingSeeder::class,
        ]);
    }
}
