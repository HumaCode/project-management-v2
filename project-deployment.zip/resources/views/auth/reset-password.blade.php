<x-guest-layout>

    @push('auth-css')
        <style>
            :root {
                --bg-deep: #040d1a;
                --bg-card: rgba(8, 22, 46, 0.72);
                --border-card: rgba(0, 200, 255, 0.12);
                --cyan: #00c8ff;
                --cyan-glow: rgba(0, 200, 255, 0.35);
                --blue: #0072c6;
                --blue-bright: #1a8fe3;
                --text: #e2eaf4;
                --text-dim: #7a90a8;
                --text-muted: #3d5068;
                --success: #00e5a0;
                --error: #ff4d6d;
                --input-bg: rgba(0, 30, 60, 0.55);
                --input-border: rgba(0, 160, 220, 0.22);
                --radius-sm: 8px;
                --font-display: 'Outfit', sans-serif;
                --font-mono: 'DM Mono', monospace;
                --transition: 0.32s cubic-bezier(0.4, 0, 0.2, 1);
            }

            *,
            *::before,
            *::after {
                box-sizing: border-box;
            }

            html,
            body {
                height: 100%;
                margin: 0;
                font-family: var(--font-display);
                background: var(--bg-deep);
                color: var(--text);
                overflow: hidden;
            }

            * {
                scrollbar-width: none;
                -ms-overflow-style: none;
            }

            *::-webkit-scrollbar {
                display: none;
            }

            #bg-canvas {
                position: fixed;
                inset: 0;
                z-index: 0;
                pointer-events: none;
            }

            .blob {
                position: fixed;
                border-radius: 50%;
                filter: blur(90px);
                pointer-events: none;
                z-index: 0;
                animation: blobFloat 16s ease-in-out infinite;
            }

            .blob-1 {
                width: 500px;
                height: 500px;
                background: radial-gradient(circle, rgba(0, 114, 198, 0.17) 0%, transparent 70%);
                top: -120px;
                right: -80px;
                animation-duration: 19s;
            }

            .blob-2 {
                width: 360px;
                height: 360px;
                background: radial-gradient(circle, rgba(0, 200, 255, 0.11) 0%, transparent 70%);
                bottom: -90px;
                left: -50px;
                animation-duration: 23s;
                animation-delay: -10s;
            }

            .blob-3 {
                width: 240px;
                height: 240px;
                background: radial-gradient(circle, rgba(0, 229, 160, 0.07) 0%, transparent 70%);
                top: 55%;
                left: 60%;
                animation-duration: 27s;
                animation-delay: -5s;
            }

            @keyframes blobFloat {

                0%,
                100% {
                    transform: translate(0, 0) scale(1);
                }

                33% {
                    transform: translate(24px, -18px) scale(1.04);
                }

                66% {
                    transform: translate(-18px, 22px) scale(0.97);
                }
            }

            .particle {
                position: fixed;
                border-radius: 50%;
                pointer-events: none;
                z-index: 0;
                animation: floatUp linear infinite;
                opacity: 0;
            }

            @keyframes floatUp {
                0% {
                    transform: translateY(0) translateX(0);
                    opacity: 0;
                }

                10% {
                    opacity: 1;
                }

                90% {
                    opacity: .4;
                }

                100% {
                    transform: translateY(-100vh) translateX(var(--drift));
                    opacity: 0;
                }
            }

            /* ── Layout ── */
            .page-wrapper {
                position: fixed;
                inset: 0;
                z-index: 1;
                overflow-y: auto;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 24px 16px 40px;
            }

            .main-card {
                width: 100%;
                max-width: 1080px;
                background: var(--bg-card);
                backdrop-filter: blur(24px) saturate(1.4);
                -webkit-backdrop-filter: blur(24px) saturate(1.4);
                border: 1px solid var(--border-card);
                border-radius: 24px;
                overflow: hidden;
                box-shadow: 0 0 0 1px rgba(0, 200, 255, .06), 0 32px 80px rgba(0, 0, 0, .55), 0 0 120px rgba(0, 114, 198, .12);
                animation: cardIn .9s cubic-bezier(.22, 1, .36, 1) both;
                height: calc(100vh - 48px);
                align-self: flex-start;
            }

            .main-card>.col-lg-5,
            .main-card>.col-lg-7 {
                height: 100%;
            }

            @keyframes cardIn {
                from {
                    opacity: 0;
                    transform: translateY(28px) scale(.97);
                }

                to {
                    opacity: 1;
                    transform: translateY(0) scale(1);
                }
            }

            /* ── Brand Panel ── */
            .brand-panel {
                background: linear-gradient(145deg, rgba(0, 30, 70, .9) 0%, rgba(0, 15, 40, .95) 100%);
                border-right: 1px solid var(--border-card);
                padding: 52px 40px;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                position: relative;
                overflow-y: auto;
            }

            .brand-panel::before {
                content: '';
                position: absolute;
                inset: 0;
                background-image: linear-gradient(rgba(0, 200, 255, .04) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 200, 255, .04) 1px, transparent 1px);
                background-size: 32px 32px;
                pointer-events: none;
            }

            .brand-panel::after {
                content: '';
                position: absolute;
                bottom: -60px;
                left: -60px;
                width: 300px;
                height: 300px;
                background: radial-gradient(circle, rgba(0, 200, 255, .07) 0%, transparent 65%);
                pointer-events: none;
            }

            .brand-logo {
                display: flex;
                align-items: center;
                gap: 12px;
                animation: fadeUp .6s .2s both;
            }

            .logo-icon {
                width: 46px;
                height: 46px;
                background: linear-gradient(135deg, var(--cyan) 0%, var(--blue) 100%);
                border-radius: 12px;
                display: grid;
                place-items: center;
                font-size: 22px;
                color: #fff;
                box-shadow: 0 0 24px var(--cyan-glow);
                position: relative;
                overflow: hidden;
                flex-shrink: 0;
            }

            .logo-icon::after {
                content: '';
                position: absolute;
                inset: 0;
                background: linear-gradient(135deg, rgba(255, 255, 255, .25) 0%, transparent 60%);
            }

            .logo-text {
                font-family: var(--font-mono);
                font-size: 13px;
                color: var(--text-dim);
                line-height: 1.3;
            }

            .logo-text strong {
                display: block;
                font-size: 16px;
                color: var(--text);
                letter-spacing: .02em;
            }

            .brand-tag {
                font-family: var(--font-mono);
                font-size: 11px;
                color: var(--cyan);
                letter-spacing: 2px;
                text-transform: uppercase;
                margin-bottom: 16px;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .brand-tag::before {
                content: '';
                display: inline-block;
                width: 24px;
                height: 1px;
                background: var(--cyan);
                opacity: .6;
            }

            .brand-headline {
                position: relative;
                z-index: 1;
                animation: fadeUp .6s .38s both;
            }

            .brand-headline h2 {
                font-size: clamp(24px, 2.8vw, 34px);
                font-weight: 800;
                line-height: 1.25;
                color: var(--text);
                margin-bottom: 14px;
            }

            .brand-headline h2 span {
                background: linear-gradient(90deg, var(--cyan), var(--blue-bright));
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .brand-headline p {
                font-size: 13.5px;
                color: var(--text-dim);
                line-height: 1.7;
                max-width: 280px;
            }

            /* Token info card */
            .token-info {
                position: relative;
                z-index: 1;
                animation: fadeUp .6s .55s both;
            }

            .token-label {
                font-family: var(--font-mono);
                font-size: 10px;
                color: var(--text-muted);
                letter-spacing: 1.5px;
                text-transform: uppercase;
                margin-bottom: 12px;
            }

            .token-box {
                padding: 14px 16px;
                background: rgba(0, 200, 255, .05);
                border: 1px solid rgba(0, 200, 255, .12);
                border-radius: var(--radius-sm);
                margin-bottom: 10px;
            }

            .token-row {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-bottom: 6px;
            }

            .token-row:last-child {
                margin-bottom: 0;
            }

            .token-icon {
                width: 28px;
                height: 28px;
                border-radius: 50%;
                background: rgba(0, 200, 255, .1);
                display: grid;
                place-items: center;
                flex-shrink: 0;
            }

            .token-icon i {
                color: var(--cyan);
                font-size: 13px;
            }

            .token-text {
                font-size: 12px;
                color: var(--text-dim);
                line-height: 1.5;
            }

            .token-text strong {
                color: var(--text);
                font-size: 11px;
            }

            .security-badge {
                position: relative;
                z-index: 1;
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 12px 14px;
                background: rgba(0, 229, 160, .05);
                border: 1px solid rgba(0, 229, 160, .12);
                border-radius: var(--radius-sm);
                font-size: 12px;
                color: var(--text-muted);
                line-height: 1.55;
                animation: fadeUp .6s .7s both;
            }

            .security-badge i {
                color: var(--success);
                font-size: 18px;
                flex-shrink: 0;
            }

            /* ── Form Panel ── */
            .form-panel {
                display: flex;
                flex-direction: column;
                background: rgba(4, 14, 32, .6);
                overflow: hidden;
                height: 100%;
            }

            .form-scroll {
                flex: 1;
                overflow-y: auto;
                padding: 52px 48px 44px;
                height: 100%;
            }

            /* ── Form elements (identical to login/register) ── */
            .back-link {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                font-size: 13px;
                color: var(--text-muted);
                text-decoration: none;
                margin-bottom: 28px;
                transition: color var(--transition);
                font-family: var(--font-mono);
                letter-spacing: .02em;
                animation: fadeUp .5s .2s both;
            }

            .back-link:hover {
                color: var(--cyan);
            }

            .back-link i {
                transition: transform var(--transition);
            }

            .back-link:hover i {
                transform: translateX(-3px);
            }

            .form-header {
                margin-bottom: 28px;
                animation: fadeUp .6s .28s both;
            }

            .welcome-tag {
                font-family: var(--font-mono);
                font-size: 11px;
                color: var(--cyan);
                letter-spacing: 2px;
                text-transform: uppercase;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                gap: 6px;
            }

            .status-dot {
                width: 7px;
                height: 7px;
                border-radius: 50%;
                background: var(--success);
                box-shadow: 0 0 8px var(--success);
                animation: pulse 2s ease-in-out infinite;
            }

            @keyframes pulse {

                0%,
                100% {
                    opacity: 1;
                    transform: scale(1);
                }

                50% {
                    opacity: .6;
                    transform: scale(.8);
                }
            }

            .form-header h1 {
                font-size: clamp(22px, 3vw, 30px);
                font-weight: 700;
                color: var(--text);
                margin-bottom: 6px;
                line-height: 1.2;
            }

            .form-header p {
                font-size: 13.5px;
                color: var(--text-dim);
                line-height: 1.6;
            }

            .info-box {
                display: flex;
                gap: 12px;
                padding: 14px 16px;
                background: rgba(0, 200, 255, .05);
                border: 1px solid rgba(0, 200, 255, .12);
                border-radius: var(--radius-sm);
                margin-bottom: 24px;
                animation: fadeUp .5s .3s both;
            }

            .info-box i {
                color: var(--cyan);
                font-size: 18px;
                flex-shrink: 0;
                margin-top: 1px;
            }

            .info-box p {
                font-size: 13px;
                color: var(--text-dim);
                line-height: 1.6;
                margin: 0;
            }

            .info-box p strong {
                color: var(--text);
            }

            .field-group {
                margin-bottom: 20px;
                animation: fadeUp .5s both;
            }

            .field-group:nth-child(1) {
                animation-delay: .36s;
            }

            .field-group:nth-child(2) {
                animation-delay: .44s;
            }

            .field-group:nth-child(3) {
                animation-delay: .52s;
            }

            .field-label {
                display: flex;
                align-items: center;
                justify-content: space-between;
                font-family: var(--font-mono);
                font-size: 11.5px;
                font-weight: 500;
                color: var(--text-dim);
                letter-spacing: .08em;
                text-transform: uppercase;
                margin-bottom: 8px;
                transition: color var(--transition);
            }

            .field-group:focus-within .field-label {
                color: var(--cyan);
            }

            .input-wrap {
                position: relative;
            }

            .input-icon {
                position: absolute;
                left: 16px;
                top: 50%;
                transform: translateY(-50%);
                color: var(--text-muted);
                font-size: 16px;
                pointer-events: none;
                transition: color var(--transition);
                z-index: 2;
            }

            .field-group:focus-within .input-icon {
                color: var(--cyan);
            }

            .form-input {
                width: 100%;
                height: 52px;
                padding: 0 46px 0 46px;
                background: var(--input-bg);
                border: 1px solid var(--input-border);
                border-radius: var(--radius-sm);
                color: var(--text);
                font-family: var(--font-display);
                font-size: 14px;
                outline: none;
                transition: var(--transition);
                -webkit-appearance: none;
            }

            .form-input::placeholder {
                color: var(--text-muted);
            }

            .form-input:focus {
                border-color: var(--cyan);
                background: rgba(0, 40, 80, .7);
                box-shadow: 0 0 0 3px rgba(0, 200, 255, .1), inset 0 1px 0 rgba(0, 200, 255, .08);
            }

            .form-input.is-valid {
                border-color: rgba(0, 229, 160, .5);
            }

            .form-input.is-invalid {
                border-color: rgba(255, 77, 109, .5);
                background: rgba(40, 8, 16, .5);
            }

            .input-line {
                position: absolute;
                bottom: 0;
                left: 50%;
                transform: translateX(-50%) scaleX(0);
                width: calc(100% - 2px);
                height: 2px;
                background: linear-gradient(90deg, transparent, var(--cyan), transparent);
                border-radius: 0 0 var(--radius-sm) var(--radius-sm);
                transition: transform .35s cubic-bezier(.4, 0, .2, 1);
                pointer-events: none;
            }

            .form-input:focus~.input-line {
                transform: translateX(-50%) scaleX(1);
            }

            .input-icon-right {
                position: absolute;
                right: 14px;
                top: 50%;
                transform: translateY(-50%);
                color: var(--text-muted);
                font-size: 17px;
                cursor: pointer;
                z-index: 3;
                padding: 4px;
                border-radius: 4px;
                background: none;
                border: none;
                display: flex;
                align-items: center;
                transition: color var(--transition);
            }

            .input-icon-right:hover {
                color: var(--cyan);
            }

            .field-msg {
                min-height: 18px;
                font-size: 11.5px;
                margin-top: 5px;
                padding-left: 2px;
                display: flex;
                align-items: center;
                gap: 5px;
            }

            .field-msg.error {
                color: #ff8fa3;
            }

            .field-msg.success {
                color: var(--success);
            }

            /* strength */
            .strength-wrap {
                margin-top: 8px;
            }

            .strength-bar {
                height: 3px;
                background: rgba(255, 255, 255, .06);
                border-radius: 8px;
                overflow: hidden;
                margin-bottom: 5px;
            }

            .strength-fill {
                height: 100%;
                width: 0;
                border-radius: 8px;
                transition: width .5s cubic-bezier(.4, 0, .2, 1), background .4s;
            }

            .strength-label {
                font-family: var(--font-mono);
                font-size: 10.5px;
                letter-spacing: .05em;
                color: var(--text-muted);
                display: flex;
                justify-content: space-between;
            }

            .strength-checks {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 4px 12px;
                margin-top: 8px;
            }

            .strength-check {
                font-size: 11px;
                color: var(--text-muted);
                display: flex;
                align-items: center;
                gap: 5px;
                transition: color .25s;
            }

            .strength-check.pass {
                color: var(--success);
            }

            /* submit */
            .btn-submit {
                width: 100%;
                height: 52px;
                background: linear-gradient(135deg, var(--blue) 0%, var(--cyan) 100%);
                border: none;
                border-radius: var(--radius-sm);
                color: #fff;
                font-family: var(--font-display);
                font-size: 15px;
                font-weight: 600;
                letter-spacing: .04em;
                cursor: pointer;
                position: relative;
                overflow: hidden;
                transition: var(--transition);
                box-shadow: 0 4px 24px rgba(0, 114, 198, .35);
                margin-top: 8px;
            }

            .btn-submit::before {
                content: '';
                position: absolute;
                inset: 0;
                background: linear-gradient(135deg, var(--cyan) 0%, var(--blue) 100%);
                opacity: 0;
                transition: opacity var(--transition);
            }

            .btn-submit:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 36px rgba(0, 200, 255, .35);
            }

            .btn-submit:hover::before {
                opacity: 1;
            }

            .btn-submit:active {
                transform: translateY(0);
            }

            .btn-submit span {
                position: relative;
                z-index: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
            }

            .btn-submit::after {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 60%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255, 255, 255, .18), transparent);
                transform: skewX(-20deg);
                animation: shimmer 4s 2s ease-in-out infinite;
            }

            @keyframes shimmer {
                0% {
                    left: -100%
                }

                40%,
                100% {
                    left: 160%
                }
            }

            .spinner-ring {
                display: none;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 22px;
                height: 22px;
            }

            .btn-submit.loading .spinner-ring {
                display: block;
            }

            .btn-submit.loading span {
                opacity: 0;
            }

            .spinner-ring svg {
                animation: spin .9s linear infinite;
            }

            @keyframes spin {
                to {
                    transform: rotate(360deg)
                }
            }

            /* success */
            .success-panel {
                text-align: center;
                padding: 20px 0;
                animation: fadeUp .6s both;
            }

            .success-icon-wrap {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                background: rgba(0, 229, 160, .1);
                border: 2px solid rgba(0, 229, 160, .25);
                display: grid;
                place-items: center;
                margin: 0 auto 20px;
                animation: scaleIn .5s .1s cubic-bezier(.34, 1.56, .64, 1) both;
                position: relative;
            }

            .success-icon-wrap::after {
                content: '';
                position: absolute;
                inset: -8px;
                border-radius: 50%;
                border: 1px solid rgba(0, 229, 160, .1);
                animation: ringPulse 2.5s ease-in-out infinite;
            }

            @keyframes scaleIn {
                from {
                    transform: scale(.5);
                    opacity: 0;
                }

                to {
                    transform: scale(1);
                    opacity: 1;
                }
            }

            @keyframes ringPulse {

                0%,
                100% {
                    transform: scale(1);
                    opacity: .5;
                }

                50% {
                    transform: scale(1.12);
                    opacity: 0;
                }
            }

            .success-icon-wrap i {
                font-size: 32px;
                color: var(--success);
            }

            .success-panel h3 {
                font-size: 22px;
                font-weight: 700;
                color: var(--text);
                margin-bottom: 8px;
            }

            .success-panel p {
                font-size: 14px;
                color: var(--text-dim);
                line-height: 1.65;
                max-width: 320px;
                margin: 0 auto;
            }

            .sys-info {
                font-family: var(--font-mono);
                font-size: 10px;
                color: var(--text-muted);
                text-align: center;
                margin-top: 16px;
                letter-spacing: .06em;
            }

            .sys-info span {
                color: var(--cyan);
                opacity: .7;
            }

            .login-back {
                text-align: center;
                margin-top: 20px;
                font-size: 13px;
                color: var(--text-muted);
            }

            .login-back a {
                color: var(--cyan);
                text-decoration: none;
                font-weight: 600;
                transition: color var(--transition);
            }

            .login-back a:hover {
                color: #fff;
            }

            @keyframes fadeUp {
                from {
                    opacity: 0;
                    transform: translateY(14px);
                }

                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            /* token expired */
            .expired-panel {
                text-align: center;
                padding: 20px 0;
                animation: fadeUp .6s both;
            }

            .expired-icon-wrap {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                background: rgba(255, 77, 109, .08);
                border: 2px solid rgba(255, 77, 109, .2);
                display: grid;
                place-items: center;
                margin: 0 auto 20px;
                animation: scaleIn .5s .1s cubic-bezier(.34, 1.56, .64, 1) both;
            }

            .expired-icon-wrap i {
                font-size: 32px;
                color: var(--error);
            }

            .expired-panel h3 {
                font-size: 22px;
                font-weight: 700;
                color: var(--text);
                margin-bottom: 8px;
            }

            .expired-panel p {
                font-size: 14px;
                color: var(--text-dim);
                line-height: 1.65;
                max-width: 320px;
                margin: 0 auto 24px;
            }

            input:-webkit-autofill,
            input:-webkit-autofill:focus {
                -webkit-box-shadow: 0 0 0 1000px rgba(0, 30, 60, .9) inset;
                -webkit-text-fill-color: var(--text);
                transition: background-color 9999s ease;
            }

            @media(max-width:991.98px) {
                .page-wrapper {
                    align-items: flex-start;
                }

                .main-card {
                    height: auto;
                    align-self: auto;
                    border-radius: 18px;
                }

                .main-card>.col-lg-5,
                .main-card>.col-lg-7 {
                    height: auto;
                }

                .form-panel {
                    overflow: visible;
                    height: auto;
                }

                .form-scroll {
                    overflow-y: visible;
                    height: auto;
                    padding: 36px 32px 40px;
                }

                .brand-panel {
                    overflow-y: visible;
                    padding: 28px 28px 24px;
                    border-right: none;
                    border-bottom: 1px solid var(--border-card);
                }

                .token-info {
                    display: none;
                }

                .security-badge {
                    display: none;
                }
            }

            @media(max-width:575.98px) {
                .page-wrapper {
                    padding: 12px 10px 32px;
                }

                .brand-panel {
                    padding: 22px 18px 20px;
                }

                .brand-headline h2 {
                    font-size: 21px;
                }

                .form-scroll {
                    padding: 26px 20px 32px;
                }

                .main-card {
                    border-radius: 16px;
                }

                .strength-checks {
                    grid-template-columns: 1fr;
                }
            }

            @media(min-width:992px) {
                .page-wrapper {
                    align-items: center;
                }
            }

            @media(min-width:1400px) {
                .main-card {
                    max-width: 1120px;
                }
            }
        </style>
    @endpush

    @push('auth-js')
        <script>
            const params = new URLSearchParams(window.location.search);
            const emailParam = params.get('email');
            if (emailParam) {
                document.getElementById('emailDisplay').textContent = emailParam;
            }

            /* Demo: show expired panel if ?expired=1 in URL */
            if (params.get('expired') === '1') {
                document.getElementById('panelForm').style.display = 'none';
                document.getElementById('panelExpired').style.display = 'block';
            }

            /* Toggles */
            document.getElementById('toggleNew').addEventListener('click', () => {
                const i = document.getElementById('newPass'),
                    e = document.getElementById('eyeNew'),
                    s = i.type === 'password';
                i.type = s ? 'text' : 'password';
                e.className = s ? 'bi bi-eye-slash' : 'bi bi-eye';
            });
            document.getElementById('toggleConfirm').addEventListener('click', () => {
                const i = document.getElementById('confirmPass'),
                    e = document.getElementById('eyeConfirm'),
                    s = i.type === 'password';
                i.type = s ? 'text' : 'password';
                e.className = s ? 'bi bi-eye-slash' : 'bi bi-eye';
            });

            /* Strength */
            const newPassInput = document.getElementById('newPass');
            const pwChecks = {
                len: {
                    el: document.getElementById('chkLen'),
                    test: v => v.length >= 8
                },
                upper: {
                    el: document.getElementById('chkUpper'),
                    test: v => /[A-Z]/.test(v)
                },
                num: {
                    el: document.getElementById('chkNum'),
                    test: v => /[0-9]/.test(v)
                },
                sym: {
                    el: document.getElementById('chkSym'),
                    test: v => /[!@#$%^&*()\-_=+\[\]{}|;:,.<>?]/.test(v)
                }
            };
            const levels = [{
                label: 'Sangat Lemah',
                color: '#ff4d6d',
                pct: 15
            }, {
                label: 'Lemah',
                color: '#ff7849',
                pct: 32
            }, {
                label: 'Cukup',
                color: '#f59e0b',
                pct: 55
            }, {
                label: 'Kuat',
                color: '#22d3ee',
                pct: 78
            }, {
                label: 'Sangat Kuat',
                color: '#00e5a0',
                pct: 100
            }];
            newPassInput.addEventListener('input', () => {
                const v = newPassInput.value;
                const sw = document.getElementById('strengthWrap');
                if (!v) {
                    sw.style.display = 'none';
                    newPassInput.classList.remove('is-valid', 'is-invalid');
                    return;
                }
                sw.style.display = 'block';
                let score = 0;
                Object.values(pwChecks).forEach(c => {
                    const ok = c.test(v);
                    c.el.classList.toggle('pass', ok);
                    c.el.querySelector('i').className = ok ? 'bi bi-check-circle-fill' : 'bi bi-x-circle';
                    if (ok) score++;
                });
                const lvl = levels[score];
                document.getElementById('strengthFill').style.width = lvl.pct + '%';
                document.getElementById('strengthFill').style.background =
                    `linear-gradient(90deg,${lvl.color}99,${lvl.color})`;
                document.getElementById('strengthText').textContent = lvl.label;
                document.getElementById('strengthText').style.color = lvl.color;
                document.getElementById('strengthPct').textContent = lvl.pct + '%';
                newPassInput.classList.remove('is-valid', 'is-invalid');
                if (score >= 3) newPassInput.classList.add('is-valid');
                else if (score < 2) newPassInput.classList.add('is-invalid');
                checkConfirm();
            });

            function checkConfirm() {
                const v = document.getElementById('confirmPass').value,
                    msg = document.getElementById('confirmMsg');
                if (!v) {
                    document.getElementById('confirmPass').classList.remove('is-valid', 'is-invalid');
                    msg.innerHTML = '';
                    return;
                }
                if (v === newPassInput.value) {
                    document.getElementById('confirmPass').classList.remove('is-invalid');
                    document.getElementById('confirmPass').classList.add('is-valid');
                    setMsg(msg, 'Password cocok', 'success');
                } else {
                    document.getElementById('confirmPass').classList.remove('is-valid');
                    document.getElementById('confirmPass').classList.add('is-invalid');
                    setMsg(msg, 'Password tidak cocok', 'error');
                }
            }
            document.getElementById('confirmPass').addEventListener('input', checkConfirm);

            document.getElementById('formReset').addEventListener('submit', function(e) {
                const newPass = newPassInput.value,
                    conf = document.getElementById('confirmPass').value;
                
                if (!newPassInput.classList.contains('is-valid')) {
                    e.preventDefault();
                    setMsg(document.getElementById('newPassMsg'), 'Password belum memenuhi kriteria.', 'error');
                    return;
                }
                if (newPass !== conf) {
                    e.preventDefault();
                    setMsg(document.getElementById('confirmMsg'), 'Konfirmasi password tidak cocok.', 'error');
                    return;
                }

                const btn = document.getElementById('btnSubmit');
                btn.classList.add('loading');
                btn.disabled = true;
                // Form will proceed to server naturally
            });

            function setMsg(el, text, type) {
                const icons = {
                    success: 'bi-check-circle',
                    error: 'bi-exclamation-circle',
                    info: 'bi-info-circle'
                };
                el.className = `field-msg ${type}`;
                el.innerHTML = text ? `<i class="bi ${icons[type]||''}"></i>${text}` : '';
            };
        </script>
    @endpush

    <div class="main-card row g-0 mx-auto">

        <!-- KIRI -->
        <div class="col-12 col-lg-5 brand-panel">
            <div class="brand-logo">
                <div class="logo-icon"><i class="bi bi-diagram-3-fill"></i></div>
                <div class="logo-text"><strong>PMS</strong>Project Management System</div>
            </div>
            <div class="brand-headline">
                <div class="brand-tag">Keamanan Akun</div>
                <h2>Buat Password <span>Baru</span></h2>
                <p>Anda menerima tautan reset dari email. Silakan buat password baru yang kuat untuk akun Anda.</p>
            </div>
            <div class="token-info">
                <div class="token-label">Informasi Sesi Reset</div>
                <div class="token-box">
                    <div class="token-row">
                        <div class="token-icon"><i class="bi bi-link-45deg"></i></div>
                        <div class="token-text"><strong>Token dari Email</strong><br>Tautan reset hanya berlaku satu
                            kali</div>
                    </div>
                    <div class="token-row">
                        <div class="token-icon"><i class="bi bi-clock"></i></div>
                        <div class="token-text"><strong>Kedaluwarsa dalam 60 Menit</strong><br>Segera selesaikan sebelum
                            token kadaluarsa</div>
                    </div>
                    <div class="token-row">
                        <div class="token-icon"><i class="bi bi-shield-lock"></i></div>
                        <div class="token-text"><strong>Koneksi Terenkripsi</strong><br>Data Anda dilindungi dengan SSL
                        </div>
                    </div>
                </div>
            </div>
            <div class="security-badge">
                <i class="bi bi-shield-check-fill"></i>
                <span>Jika Anda tidak meminta reset password, abaikan email tersebut. Akun Anda tetap aman.</span>
            </div>
        </div>

        <!-- KANAN -->
        <div class="col-12 col-lg-7 form-panel">
            <div class="form-scroll">

                <!-- Panel: Form Reset -->
                <div id="panelForm">
                    <a href="forgot-password.html" class="back-link"><i class="bi bi-arrow-left"></i> Kembali</a>
                    <div class="form-header">
                        <div class="welcome-tag"><span class="status-dot"></span>Token Valid</div>
                        <h1>Reset Password</h1>
                        <p>Buat password baru untuk akun <strong style="color:var(--cyan)" id="emailDisplay">–</strong>
                        </p>
                    </div>
                    <div class="info-box">
                        <i class="bi bi-key-fill"></i>
                        <p>Password baru harus berbeda dari password sebelumnya dan memenuhi kriteria keamanan yang
                            ditentukan.</p>
                    </div>

                    <form id="formReset" novalidate method="POST" action="{{ route('password.store') }}">
                        @csrf
                        <!-- Password Reset Token -->
                        <input type="hidden" name="token" value="{{ $request->route('token') }}">


                        <input type="hidden" id="emailHidden" name="email" value="{{ $request->email }}" />

                        <div class="field-group">
                            <label class="field-label" for="newPass">Password Baru</label>
                            <div class="input-wrap">
                                <i class="bi bi-lock input-icon"></i>
                                <input type="password" id="newPass" name="password" class="form-input"
                                    placeholder="Minimal 8 karakter" autocomplete="new-password" required />
                                <button type="button" class="input-icon-right" id="toggleNew"><i class="bi bi-eye"
                                        id="eyeNew"></i></button>
                                <span class="input-line"></span>
                            </div>
                            <div class="strength-wrap" id="strengthWrap" style="display:none">
                                <div class="strength-bar">
                                    <div class="strength-fill" id="strengthFill"></div>
                                </div>
                                <div class="strength-label"><span id="strengthText">Kekuatan password</span><span
                                        id="strengthPct"></span></div>
                                <div class="strength-checks">
                                    <div class="strength-check" id="chkLen"><i class="bi bi-x-circle"></i> Min. 8
                                        karakter</div>
                                    <div class="strength-check" id="chkUpper"><i class="bi bi-x-circle"></i> Huruf
                                        besar</div>
                                    <div class="strength-check" id="chkNum"><i class="bi bi-x-circle"></i> Angka
                                    </div>
                                    <div class="strength-check" id="chkSym"><i class="bi bi-x-circle"></i> Simbol
                                        (!@#$)</div>
                                </div>
                            </div>
                            <div class="field-msg" id="newPassMsg"></div>
                        </div>

                        <div class="field-group">
                            <label class="field-label" for="confirmPass">Konfirmasi Password</label>
                            <div class="input-wrap">
                                <i class="bi bi-lock-fill input-icon"></i>
                                <input type="password" id="confirmPass" name="password_confirmation" class="form-input"
                                    placeholder="Ulangi password baru" autocomplete="new-password" required />
                                <button type="button" class="input-icon-right" id="toggleConfirm"><i
                                        class="bi bi-eye" id="eyeConfirm"></i></button>
                                <span class="input-line"></span>
                            </div>
                            <div class="field-msg" id="confirmMsg"></div>
                        </div>

                        <button type="submit" class="btn-submit" id="btnSubmit">
                            <span><i class="bi bi-check-circle-fill"></i> Simpan Password Baru</span>
                            <div class="spinner-ring"><svg width="22" height="22" viewBox="0 0 22 22"
                                    fill="none">
                                    <circle cx="11" cy="11" r="9" stroke="rgba(255,255,255,.3)"
                                        stroke-width="2.5" />
                                    <path d="M11 2a9 9 0 0 1 9 9" stroke="#fff" stroke-width="2.5"
                                        stroke-linecap="round" />
                                </svg></div>
                        </button>
                    </form>

                    <div class="login-back"><a href="login.html">Kembali ke halaman Login</a></div>
                </div>

                <!-- Panel: Token Expired -->
                <div id="panelExpired" style="display:none">
                    <div class="expired-panel">
                        <div class="expired-icon-wrap"><i class="bi bi-exclamation-triangle-fill"></i></div>
                        <h3>Tautan Kedaluwarsa</h3>
                        <p>Tautan reset password ini sudah tidak valid atau telah kedaluwarsa. Silakan minta tautan
                            baru.</p>
                    </div>
                    <a href="forgot-password.html" class="btn-submit"
                        style="display:flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;color:#fff">
                        <i class="bi bi-arrow-repeat"></i> Minta Tautan Baru
                    </a>
                    <div class="login-back" style="margin-top:20px"><a href="login.html">Kembali ke Login</a></div>
                </div>

                <!-- Panel: Success -->
                <div id="panelSuccess" style="display:none">
                    <div class="success-panel">
                        <div class="success-icon-wrap"><i class="bi bi-check-lg"></i></div>
                        <h3>Password Berhasil Diubah!</h3>
                        <p>Password akun Anda telah diperbarui. Silakan masuk menggunakan password baru Anda.</p>
                    </div>
                    <div style="margin-top:32px">
                        <a href="login.html" class="btn-submit"
                            style="display:flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;color:#fff">
                            <i class="bi bi-box-arrow-in-right"></i> Masuk Sekarang
                        </a>
                    </div>
                    <div class="login-back" style="margin-top:20px">Butuh bantuan? <a href="#">Hubungi
                            Support</a></div>
                </div>

                <div class="sys-info">PMS v2.0 &mdash; <span>secure connection</span> &mdash; &copy; 2025</div>
            </div>
        </div>
    </div>


</x-guest-layout>
