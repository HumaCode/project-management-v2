<!doctype html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>419 Page Expired &mdash; Project Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet" />
    <style>
        /* ══ Reset & Variables ══ */
        :root {
            --bg: #050e1d;
            --clr: #a78bfa;
            --clr-rgb: 167, 139, 250;
            --cyan: #00c8ff;
            --blue: #0072c6;
            --txt: #e2eaf4;
            --dim: #7a90a8;
            --muted: #3d5068;
            --bd: rgba(167, 139, 250, 0.15);
            --card: rgba(7, 21, 40, 0.85);
            --font: "Poppins", sans-serif;
            --mono: "DM Mono", monospace;
            --r: 20px;
            --rs: 12px;
        }

        *,
        *::before,
        *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            height: 100%;
        }

        body {
            font-family: var(--font);
            background: var(--bg);
            color: var(--txt);
            min-height: 100vh;
            overflow-x: hidden;
            overflow-y: auto;
            /* Hide scrollbar */
            scrollbar-width: none;
            -ms-overflow-style: none;
        }

        body::-webkit-scrollbar {
            display: none;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        /* ══ Canvas ══ */
        #bgc {
            position: fixed;
            inset: 0;
            z-index: 0;
            pointer-events: none;
        }

        /* ══ Floating particles ══ */
        .particles {
            position: fixed;
            inset: 0;
            z-index: 1;
            pointer-events: none;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            border-radius: 50%;
            animation: drift linear infinite;
            opacity: 0;
        }

        @keyframes drift {
            0% {
                opacity: 0;
                transform: translateY(100vh) scale(0);
            }

            10% {
                opacity: 1;
            }

            90% {
                opacity: 0.6;
            }

            100% {
                opacity: 0;
                transform: translateY(-20vh) scale(1.2);
            }
        }

        /* ══ Grid lines background ══ */
        .grid-bg {
            position: fixed;
            inset: 0;
            z-index: 1;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(167, 139, 250, 0.04) 1px,
                    transparent 1px),
                linear-gradient(90deg,
                    rgba(167, 139, 250, 0.04) 1px,
                    transparent 1px);
            background-size: 60px 60px;
            animation: gridmove 20s linear infinite;
        }

        @keyframes gridmove {
            to {
                background-position: 60px 60px;
            }
        }

        /* ══ Scan line ══ */
        .scanline {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(90deg,
                    transparent,
                    var(--clr),
                    transparent);
            z-index: 10;
            pointer-events: none;
            animation: scan 4s ease-in-out infinite;
            box-shadow:
                0 0 20px var(--clr),
                0 0 40px var(--clr);
        }

        @keyframes scan {
            0% {
                top: -5px;
                opacity: 0;
            }

            20% {
                opacity: 1;
            }

            80% {
                opacity: 1;
            }

            100% {
                top: 105%;
                opacity: 0;
            }
        }

        /* ══ Corner decorations ══ */
        .corner {
            position: fixed;
            width: 60px;
            height: 60px;
            z-index: 2;
            pointer-events: none;
            opacity: 0.4;
        }

        .corner-tl {
            top: 20px;
            left: 20px;
            border-top: 2px solid var(--clr);
            border-left: 2px solid var(--clr);
            border-radius: 4px 0 0 0;
        }

        .corner-tr {
            top: 20px;
            right: 20px;
            border-top: 2px solid var(--clr);
            border-right: 2px solid var(--clr);
            border-radius: 0 4px 0 0;
        }

        .corner-bl {
            bottom: 20px;
            left: 20px;
            border-bottom: 2px solid var(--clr);
            border-left: 2px solid var(--clr);
            border-radius: 0 0 0 4px;
        }

        .corner-br {
            bottom: 20px;
            right: 20px;
            border-bottom: 2px solid var(--clr);
            border-right: 2px solid var(--clr);
            border-radius: 0 0 4px 0;
        }

        .corner-tl,
        .corner-tr,
        .corner-bl,
        .corner-br {
            animation: cornerpulse 3s ease-in-out infinite;
        }

        .corner-tr {
            animation-delay: 0.75s;
        }

        .corner-bl {
            animation-delay: 1.5s;
        }

        .corner-br {
            animation-delay: 2.25s;
        }

        @keyframes cornerpulse {

            0%,
            100% {
                opacity: 0.25;
            }

            50% {
                opacity: 0.65;
                filter: drop-shadow(0 0 8px var(--clr));
            }
        }

        /* ══ Orbiting rings ══ */
        .ring-wrap {
            position: absolute;
            border-radius: 50%;
            border: 1px solid transparent;
            animation: orbit linear infinite;
            pointer-events: none;
        }

        @keyframes orbit {
            to {
                transform: rotate(360deg);
            }
        }

        /* ══ Main layout ══ */
        .page-wrap {
            position: relative;
            z-index: 10;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .card-wrap {
            width: 100%;
            max-width: 620px;
            text-align: center;
            animation: cardin 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) both;
        }

        @keyframes cardin {
            from {
                opacity: 0;
                transform: translateY(40px) scale(0.94);
            }

            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        /* ══ Error code display ══ */
        .err-code {
            font-family: var(--mono);
            font-size: clamp(72px, 14vw, 148px);
            font-weight: 800;
            line-height: 1;
            letter-spacing: -4px;
            background: linear-gradient(135deg,
                    var(--clr),
                    color-mix(in srgb, var(--clr) 60%, #fff 40%));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            filter: drop-shadow(0 0 30px var(--clr));
            animation: codepulse 2.5s ease-in-out infinite;
            position: relative;
            display: inline-block;
            margin-bottom: 8px;
        }

        @keyframes codepulse {

            0%,
            100% {
                filter: drop-shadow(0 0 20px var(--clr)) drop-shadow(0 0 60px color-mix(in srgb, var(--clr) 40%, transparent));
            }

            50% {
                filter: drop-shadow(0 0 40px var(--clr)) drop-shadow(0 0 100px color-mix(in srgb, var(--clr) 60%, transparent));
            }
        }

        /* Glitch effect on code */
        .err-code::before,
        .err-code::after {
            content: attr(data-text);
            position: absolute;
            inset: 0;
            background: inherit;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .err-code::before {
            left: 2px;
            filter: drop-shadow(-2px 0 #ff4d6d);
            animation: glitch1 4s infinite;
            clip-path: polygon(0 0, 100% 0, 100% 35%, 0 35%);
        }

        .err-code::after {
            left: -2px;
            filter: drop-shadow(2px 0 var(--cyan));
            animation: glitch2 4s infinite;
            clip-path: polygon(0 65%, 100% 65%, 100% 100%, 0 100%);
        }

        @keyframes glitch1 {

            0%,
            90%,
            100% {
                opacity: 0;
                transform: translate(0);
            }

            91% {
                opacity: 0.8;
                transform: translate(-3px, 1px);
            }

            93% {
                opacity: 0.8;
                transform: translate(3px, -1px);
            }

            95% {
                opacity: 0;
            }
        }

        @keyframes glitch2 {

            0%,
            92%,
            100% {
                opacity: 0;
                transform: translate(0);
            }

            93% {
                opacity: 0.7;
                transform: translate(3px, 2px);
            }

            95% {
                opacity: 0.7;
                transform: translate(-3px, -2px);
            }

            97% {
                opacity: 0;
            }
        }

        /* ══ Icon area ══ */
        .icon-zone {
            position: relative;
            width: 140px;
            height: 140px;
            margin: 0 auto 28px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .icon-bg {
            position: absolute;
            inset: 0;
            border-radius: 50%;
            background: radial-gradient(circle,
                    color-mix(in srgb, var(--clr) 15%, transparent),
                    transparent 70%);
            animation: iconbg 3s ease-in-out infinite;
        }

        @keyframes iconbg {

            0%,
            100% {
                transform: scale(1);
                opacity: 0.6;
            }

            50% {
                transform: scale(1.15);
                opacity: 1;
            }
        }

        .icon-ring1 {
            position: absolute;
            inset: -10px;
            border-radius: 50%;
            border: 1.5px solid color-mix(in srgb, var(--clr) 35%, transparent);
            animation: spinring 8s linear infinite;
        }

        .icon-ring2 {
            position: absolute;
            inset: -22px;
            border-radius: 50%;
            border: 1px dashed color-mix(in srgb, var(--clr) 25%, transparent);
            animation: spinring 14s linear infinite reverse;
        }

        .icon-ring3 {
            position: absolute;
            inset: -38px;
            border-radius: 50%;
            border: 1px solid color-mix(in srgb, var(--clr) 15%, transparent);
            animation: spinring 20s linear infinite;
        }

        @keyframes spinring {
            to {
                transform: rotate(360deg);
            }
        }

        .icon-dot {
            position: absolute;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--clr);
            box-shadow:
                0 0 10px var(--clr),
                0 0 20px var(--clr);
            top: 50%;
            left: 50%;
            transform-origin: 0 0;
            animation: dotorbit 8s linear infinite;
        }

        .icon-dot2 {
            width: 5px;
            height: 5px;
            background: var(--cyan);
            box-shadow: 0 0 8px var(--cyan);
            animation-duration: 14s;
            animation-direction: reverse;
            top: calc(50% + 22px);
        }

        @keyframes dotorbit {
            0% {
                transform: translate(-4px, -4px) rotate(0deg) translateX(45px);
            }

            100% {
                transform: translate(-4px, -4px) rotate(360deg) translateX(45px);
            }
        }

        .icon-main {
            position: relative;
            z-index: 2;
            font-size: 56px;
            color: var(--clr);
            filter: drop-shadow(0 0 16px var(--clr));
            animation: iconbounce 2s ease-in-out infinite;
            display: block;
        }

        @keyframes iconbounce {

            0%,
            100% {
                transform: translateY(0) scale(1);
                filter: drop-shadow(0 0 16px var(--clr));
            }

            50% {
                transform: translateY(-8px) scale(1.05);
                filter: drop-shadow(0 0 28px var(--clr)) drop-shadow(0 0 50px color-mix(in srgb, var(--clr) 50%, transparent));
            }
        }

        /* 419 clock tick */
        @keyframes clocktick {
            0% {
                transform: translateY(0) scale(1) rotate(0deg);
            }

            25% {
                transform: translateY(-6px) scale(1.06) rotate(-8deg);
            }

            50% {
                transform: translateY(-8px) scale(1.08) rotate(0deg);
            }

            75% {
                transform: translateY(-6px) scale(1.06) rotate(8deg);
            }

            100% {
                transform: translateY(0) scale(1) rotate(0deg);
            }
        }

        @keyframes hourglass {

            0%,
            100% {
                transform: rotate(0deg);
            }

            50% {
                transform: rotate(180deg);
            }
        }

        #mainIcon {
            animation: clocktick 2.5s ease-in-out infinite;
        }

        .timer-badge {
            position: absolute;
            bottom: 6px;
            right: 4px;
            font-family: "DM Mono", monospace;
            font-size: 10px;
            font-weight: 700;
            color: #a78bfa;
            background: rgba(167, 139, 250, 0.15);
            border: 1px solid rgba(167, 139, 250, 0.3);
            border-radius: 6px;
            padding: 2px 6px;
            box-shadow: 0 0 8px rgba(167, 139, 250, 0.4);
            animation: codepulse 1.5s ease-in-out infinite;
        }

        /* ══ Text ══ */
        .err-type {
            font-family: var(--mono);
            font-size: 11px;
            letter-spacing: 3px;
            text-transform: uppercase;
            color: var(--clr);
            margin-bottom: 10px;
            opacity: 0.85;
        }

        .err-title {
            font-size: clamp(22px, 4vw, 32px);
            font-weight: 800;
            line-height: 1.2;
            margin-bottom: 12px;
        }

        .err-desc {
            font-size: 15px;
            color: var(--dim);
            line-height: 1.7;
            max-width: 480px;
            margin: 0 auto 28px;
        }

        /* ══ Neon divider ══ */
        .neon-div {
            width: 80px;
            height: 2px;
            background: linear-gradient(90deg,
                    transparent,
                    var(--clr),
                    transparent);
            margin: 0 auto 24px;
            border-radius: 2px;
            box-shadow: 0 0 12px var(--clr);
            animation: divpulse 2s ease-in-out infinite;
        }

        @keyframes divpulse {

            0%,
            100% {
                width: 60px;
                opacity: 0.7;
            }

            50% {
                width: 120px;
                opacity: 1;
            }
        }

        /* ══ Info box ══ */
        .info-box {
            background: rgba(167, 139, 250, 0.05);
            border: 1px solid rgba(167, 139, 250, 0.15);
            border-left: 3px solid var(--clr);
            border-radius: var(--rs);
            padding: 14px 18px;
            margin-bottom: 28px;
            text-align: left;
            font-family: var(--mono);
            font-size: 12px;
            color: var(--dim);
            line-height: 1.8;
        }

        .info-box .ib-row {
            display: flex;
            gap: 8px;
            align-items: baseline;
        }

        .info-box .ib-lbl {
            color: var(--clr);
            font-weight: 600;
            min-width: 80px;
            flex-shrink: 0;
        }

        /* ══ Buttons ══ */
        .btn-row {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-primary {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 0 24px;
            height: 46px;
            border-radius: var(--rs);
            background: linear-gradient(135deg,
                    color-mix(in srgb, var(--clr) 70%, #000),
                    var(--clr));
            border: none;
            color: #fff;
            font-family: var(--font);
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s;
            -webkit-tap-highlight-color: transparent;
            box-shadow: 0 0 20px rgba(167, 139, 250, 0.3);
        }

        .btn-primary::before {
            content: "";
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, var(--clr), #fff);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow:
                0 0 30px rgba(167, 139, 250, 0.6),
                0 8px 24px rgba(0, 0, 0, 0.3);
        }

        .btn-primary:hover::before {
            opacity: 0.15;
        }

        .btn-primary span {
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-secondary {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 0 22px;
            height: 46px;
            border-radius: var(--rs);
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(167, 139, 250, 0.25);
            color: var(--dim);
            font-family: var(--font);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            -webkit-tap-highlight-color: transparent;
        }

        .btn-secondary:hover {
            background: rgba(167, 139, 250, 0.1);
            color: var(--clr);
            border-color: rgba(167, 139, 250, 0.5);
            transform: translateY(-2px);
        }

        /* ══ Status bar ══ */
        .status-bar {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin-top: 32px;
            font-family: var(--mono);
            font-size: 11px;
            color: var(--muted);
        }

        .status-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: var(--clr);
            box-shadow: 0 0 6px var(--clr);
            animation: sdot 2s ease-in-out infinite;
        }

        @keyframes sdot {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.3;
            }
        }

        /* ══ Floating debris (random shapes) ══ */
        .debris {
            position: fixed;
            z-index: 1;
            pointer-events: none;
            opacity: 0;
            animation: dbdrift linear infinite;
        }

        @keyframes dbdrift {
            0% {
                opacity: 0;
                transform: translateY(110vh) rotate(0deg);
            }

            5% {
                opacity: 0.4;
            }

            95% {
                opacity: 0.3;
            }

            100% {
                opacity: 0;
                transform: translateY(-20vh) rotate(720deg);
            }
        }

        /* ══ Responsive ══ */
        @media (max-width: 767.98px) {
            .page-wrap {
                padding: 30px 16px;
            }

            .err-code {
                font-size: clamp(64px, 18vw, 100px);
                letter-spacing: -2px;
            }

            .icon-zone {
                width: 110px;
                height: 110px;
            }

            .icon-main {
                font-size: 42px;
            }

            .icon-ring3 {
                inset: -28px;
            }

            .err-title {
                font-size: clamp(18px, 5vw, 24px);
            }

            .err-desc {
                font-size: 14px;
            }

            .btn-primary,
            .btn-secondary {
                height: 42px;
                padding: 0 18px;
                font-size: 13px;
            }

            .corner {
                width: 40px;
                height: 40px;
                top: 12px;
            }

            .corner-tl,
            .corner-tr {
                top: 12px;
            }

            .corner-tr {
                right: 12px;
            }

            .corner-tl {
                left: 12px;
            }

            .corner-bl,
            .corner-br {
                bottom: 12px;
            }

            .corner-br {
                right: 12px;
            }

            .corner-bl {
                left: 12px;
            }
        }

        @media (max-width: 575.98px) {
            .page-wrap {
                padding: 24px 14px;
            }

            .btn-row {
                flex-direction: column;
                align-items: center;
            }

            .btn-primary,
            .btn-secondary {
                width: 100%;
                max-width: 300px;
                justify-content: center;
            }

            .info-box .ib-row {
                flex-direction: column;
                gap: 2px;
            }

            .info-box .ib-lbl {
                min-width: auto;
            }
        }

        @media (min-width: 1200px) {
            .card-wrap {
                max-width: 680px;
            }
        }

        @media (min-width: 1600px) {
            .page-wrap {
                padding: 60px 20px;
            }
        }
    </style>
</head>

<body>
    <!-- Background canvas -->
    <canvas id="bgc"></canvas>

    <!-- Grid & effects -->
    <div class="grid-bg"></div>
    <div class="scanline"></div>
    <div class="corner corner-tl"></div>
    <div class="corner corner-tr"></div>
    <div class="corner corner-bl"></div>
    <div class="corner corner-br"></div>

    <!-- Floating particles container -->
    <div class="particles" id="particles"></div>

    <!-- Main content -->
    <div class="page-wrap">
        <div class="card-wrap">
            <!-- Error code -->
            <div class="err-code" data-text="419">419</div>
            <div class="err-type">Page Expired</div>

            <!-- Icon -->
            <div class="icon-zone">
                <div class="icon-bg"></div>
                <div class="icon-ring1"></div>
                <div class="icon-ring2"></div>
                <div class="icon-ring3"></div>
                <div class="icon-dot"></div>
                <div class="icon-dot icon-dot2"></div>
                <i class="bi bi-clock-history icon-main" id="mainIcon"></i>
                <div class="timer-badge" id="timerBadge">00:00</div>
            </div>

            <!-- Title & description -->
            <h1 class="err-title">Sesi Halaman Kedaluwarsa</h1>
            <div class="neon-div"></div>
            <p class="err-desc">
                Token keamanan Anda telah kedaluwarsa. Ini terjadi ketika
                halaman dibiarkan terlalu lama tanpa aktivitas.
            </p>

            <!-- Info box -->
            <div class="info-box">
                <div class="ib-row">
                    <span class="ib-lbl">Kode Error</span><span>419 Page Expired</span>
                </div>
                <div class="ib-row">
                    <span class="ib-lbl">Penyebab</span><span>CSRF token kedaluwarsa atau sesi browser
                        habis</span>
                </div>
                <div class="ib-row">
                    <span class="ib-lbl">Solusi</span><span>Muat ulang halaman dan masukkan data kembali</span>
                </div>
            </div>

            <!-- Buttons -->
            <div class="btn-row">
                <a href="{{ route('dashboard') }}" class="btn-primary">
                    <span>
                        <i class="bi bi-house-fill"></i> Kembali ke
                        Dashboard
                    </span>
                </a>
                <button class="btn-secondary" onclick="javascript: history.back();">
                    <i class="bi bi-arrow-left-short" style="font-size: 18px"></i>
                    Halaman Sebelumnya
                </button>
            </div>

            <!-- Status bar -->
            <div class="status-bar">
                <div class="status-dot"></div>
                <span>HTTP 419 &nbsp;&bull;&nbsp; pmssystem.id
                    &nbsp;&bull;&nbsp; <span id="errTime"></span></span>
            </div>
        </div>
    </div>

    <script>
        // ── Time ──────────────────────────────────────────────────────────
        (function() {
            var el = document.getElementById("errTime");

            function upd() {
                var d = new Date();
                el.textContent = d.toLocaleTimeString("id-ID", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                });
            }
            upd();
            setInterval(upd, 1000);
        })();

        // ── Canvas background ─────────────────────────────────────────────
        (function() {
            var cv = document.getElementById("bgc"),
                ctx = cv.getContext("2d");
            var W,
                H,
                pts = [];
            var CLR = "#a78bfa",
                CLR_RGB = "167,139,250";

            function hex2rgb(h) {
                var r = parseInt(h.slice(1, 3), 16),
                    g = parseInt(h.slice(3, 5), 16),
                    b = parseInt(h.slice(5, 7), 16);
                return [r, g, b];
            }
            var RGB = hex2rgb(CLR);

            function init() {
                W = cv.width = window.innerWidth;
                H = cv.height = window.innerHeight;
                pts = [];
                var n = Math.max(20, Math.floor((W * H) / 28000));
                for (var i = 0; i < n; i++)
                    pts.push({
                        x: Math.random() * W,
                        y: Math.random() * H,
                        vx: (Math.random() - 0.5) * 0.35,
                        vy: (Math.random() - 0.5) * 0.35,
                        r: Math.random() * 2 + 0.5,
                        p: Math.random() * Math.PI * 2,
                    });
            }

            function draw() {
                ctx.clearRect(0, 0, W, H);
                // Radial glow center
                var grd = ctx.createRadialGradient(
                    W * 0.5,
                    H * 0.5,
                    0,
                    W * 0.5,
                    H * 0.5,
                    Math.max(W, H) * 0.7,
                );
                grd.addColorStop(
                    0,
                    "rgba(" +
                    RGB[0] +
                    "," +
                    RGB[1] +
                    "," +
                    RGB[2] +
                    ",.06)",
                );
                grd.addColorStop(1, "transparent");
                ctx.fillStyle = grd;
                ctx.fillRect(0, 0, W, H);
                // Secondary corner glows
                [{
                        x: 0,
                        y: 0
                    },
                    {
                        x: W,
                        y: H
                    },
                ].forEach(function(c) {
                    var g2 = ctx.createRadialGradient(
                        c.x,
                        c.y,
                        0,
                        c.x,
                        c.y,
                        300,
                    );
                    g2.addColorStop(0, "rgba(0,114,198,.07)");
                    g2.addColorStop(1, "transparent");
                    ctx.fillStyle = g2;
                    ctx.fillRect(0, 0, W, H);
                });
                // Connect lines
                for (var i = 0; i < pts.length; i++)
                    for (var j = i + 1; j < pts.length; j++) {
                        var a = pts[i],
                            b = pts[j],
                            dx = a.x - b.x,
                            dy = a.y - b.y,
                            d = Math.sqrt(dx * dx + dy * dy);
                        if (d < 140) {
                            ctx.beginPath();
                            ctx.moveTo(a.x, a.y);
                            ctx.lineTo(b.x, b.y);
                            ctx.strokeStyle =
                                "rgba(" +
                                RGB[0] +
                                "," +
                                RGB[1] +
                                "," +
                                RGB[2] +
                                "," +
                                (1 - d / 140) * 0.12 +
                                ")";
                            ctx.lineWidth = 0.8;
                            ctx.stroke();
                        }
                    }
                // Dots
                pts.forEach(function(p) {
                    p.x += p.vx;
                    p.y += p.vy;
                    p.p += 0.015;
                    if (p.x < -10) p.x = W + 10;
                    if (p.x > W + 10) p.x = -10;
                    if (p.y < -10) p.y = H + 10;
                    if (p.y > H + 10) p.y = -10;
                    var a = 0.25 + Math.sin(p.p) * 0.2;
                    ctx.beginPath();
                    ctx.arc(
                        p.x,
                        p.y,
                        p.r * (0.8 + Math.sin(p.p) * 0.2),
                        0,
                        Math.PI * 2,
                    );
                    ctx.fillStyle =
                        "rgba(" +
                        RGB[0] +
                        "," +
                        RGB[1] +
                        "," +
                        RGB[2] +
                        "," +
                        a +
                        ")";
                    ctx.fill();
                    // Glow
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.r * 3, 0, Math.PI * 2);
                    ctx.fillStyle =
                        "rgba(" +
                        RGB[0] +
                        "," +
                        RGB[1] +
                        "," +
                        RGB[2] +
                        ",.04)";
                    ctx.fill();
                });
                requestAnimationFrame(draw);
            }
            window.addEventListener("resize", init, {
                passive: true
            });
            init();
            draw();
        })();

        // ── Floating particles ─────────────────────────────────────────────
        (function() {
            var container = document.getElementById("particles");
            var CLR = ["#a78bfa", "#00c8ff", "#0072c6"];
            for (var i = 0; i < 22; i++) {
                var el = document.createElement("div");
                el.className = "particle";
                var size = Math.random() * 6 + 2;
                var c = CLR[Math.floor(Math.random() * CLR.length)];
                el.style.cssText = [
                    "width:" + size + "px",
                    "height:" + size + "px",
                    "left:" + Math.random() * 100 + "%",
                    "background:" + c,
                    "box-shadow:0 0 " + size * 3 + "px " + c,
                    "animation-duration:" + (8 + Math.random() * 14) + "s",
                    "animation-delay:" + Math.random() * 10 + "s",
                ].join(";");
                container.appendChild(el);
            }
            // Debris (random shapes)
            var shapes = ["◆", "◇", "▸", "▪", "◉", "∘", "⬡", "✦"];
            for (var j = 0; j < 10; j++) {
                var d = document.createElement("div");
                d.className = "debris";
                d.textContent =
                    shapes[Math.floor(Math.random() * shapes.length)];
                d.style.cssText = [
                    "color:rgba(" + "167,139,250" + ".15)",
                    "font-size:" + (10 + Math.random() * 16) + "px",
                    "left:" + Math.random() * 100 + "%",
                    "animation-duration:" + (12 + Math.random() * 18) + "s",
                    "animation-delay:" + Math.random() * 15 + "s",
                ].join(";");
                document.body.appendChild(d);
            }
        })();
    </script>

    <script>
        (function() {
            var s = 0,
                el = document.getElementById("timerBadge");
            setInterval(function() {
                s++;
                var m = Math.floor(s / 60),
                    sec = s % 60;
                el.textContent =
                    (m < 10 ? "0" : "") +
                    m +
                    ":" +
                    (sec < 10 ? "0" : "") +
                    sec;
            }, 1000);
        })();
    </script>
</body>

</html>
